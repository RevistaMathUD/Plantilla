Aquí se guardan las imagenes

