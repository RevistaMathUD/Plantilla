Los paquetes fuera de la plantilla estándar son
answers (principal)
shellesc